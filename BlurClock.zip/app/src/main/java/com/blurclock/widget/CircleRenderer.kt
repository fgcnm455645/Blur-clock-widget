package com.blurclock.widget

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.roundToInt

object CircleRenderer {

    fun size(s: ClockSettings) = (s.circleSize * s.wallW).roundToInt().coerceAtLeast(8)

    /**
     * Round button: the blurred wallpaper fill clipped to a circle (optionally as liquid glass),
     * an optional white frame, and the user's logo in the middle.
     * outW/outH = real widget size in px; the circle keeps its exact size (never upscaled) and is
     * centered in a transparent image of the widget size.
     */
    fun render(
        s: ClockSettings, idx: Int, fill: Bitmap?, logo: Bitmap?, glass: Boolean,
        outW: Int = 0, outH: Int = 0
    ): Bitmap {
        val full = size(s)
        val cw = if (outW > 0) outW else full
        val ch = if (outH > 0) outH else full
        val d = minOf(full, cw, ch)
        val bmp = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.translate((cw - d) / 2f, (ch - d) / 2f)

        val stroke = if (s.frameOn) (s.frameThick * d).coerceAtLeast(1f) else 0f
        val r = d / 2f - stroke / 2f

        if (fill != null && glass && s.gCircle.on) {
            // The glass runs on a padded canvas: when the circle touched the bitmap border, the distance
            // field / normals were wrong at the 4 touching points and the rim broke there.
            val pad = maxOf(8, (d * 0.05f).toInt())
            val pd = d + 2 * pad
            val scaled = if (fill.width == d && fill.height == d) fill else Bitmap.createScaledBitmap(fill, d, d, true)
            val mb = Bitmap.createBitmap(pd, pd, Bitmap.Config.ARGB_8888)
            Canvas(mb).drawCircle(pd / 2f, pd / 2f, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE })
            val n = pd * pd
            val ap = IntArray(n)
            mb.getPixels(ap, 0, pd, 0, 0, pd, pd)
            for (i in 0 until n) ap[i] = ap[i] ushr 24
            // backdrop: the fill in the middle, its edge pixels extended outwards
            val fb = Bitmap.createBitmap(pd, pd, Bitmap.Config.ARGB_8888)
            val fc = Canvas(fb)
            fc.translate(pad.toFloat(), pad.toFloat())
            fc.drawRect(
                -pad.toFloat(), -pad.toFloat(), (d + pad).toFloat(), (d + pad).toFloat(),
                Paint().apply { shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) }
            )
            val fp = IntArray(n)
            fb.getPixels(fp, 0, pd, 0, 0, pd, pd)
            val res = LiquidGlass.apply(ap, fp, pd, pd, s.gCircle.toParams(d * 2.5f))
            val gb = Bitmap.createBitmap(pd, pd, Bitmap.Config.ARGB_8888)
            gb.setPixels(res, 0, pd, 0, 0, pd, pd)
            c.drawBitmap(gb, Rect(pad, pad, pad + d, pad + d), Rect(0, 0, d, d), null)
            mb.recycle()
            fb.recycle()
            gb.recycle()
        } else {
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            if (fill != null) {
                val scaled = if (fill.width == d && fill.height == d) fill else Bitmap.createScaledBitmap(fill, d, d, true)
                fillPaint.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            } else {
                fillPaint.color = Color.argb(90, 255, 255, 255)
            }
            c.drawCircle(d / 2f, d / 2f, r, fillPaint)
        }

        if (s.frameOn) {
            val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                color = Color.argb((s.frameAlpha / 100f * 255f).roundToInt(), 255, 255, 255)
            }
            c.drawCircle(d / 2f, d / 2f, r, ring)
        }

        if (logo != null && logo.width > 0 && logo.height > 0) {
            val box = s.logoSize[idx] * d
            val ratio = logo.width.toFloat() / logo.height
            val lw: Float
            val lh: Float
            if (ratio >= 1f) {
                lw = box
                lh = box / ratio
            } else {
                lh = box
                lw = box * ratio
            }
            val dst = RectF(d / 2f - lw / 2f, d / 2f - lh / 2f, d / 2f + lw / 2f, d / 2f + lh / 2f)
            val lp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            if (s.logoWhite[idx]) lp.colorFilter = PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
            c.drawBitmap(logo, null, dst, lp)
        }
        return bmp
    }
}
