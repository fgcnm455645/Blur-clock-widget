package com.blurclock.widget

import kotlin.math.max
import kotlin.math.roundToInt

/*
 * "Real" liquid glass for the clock digits.
 *
 * Same recipe as the Backdrop library demos (Kyant, Apache License 2.0,
 * http://www.apache.org/licenses/LICENSE-2.0): vibrancy -> blur -> lens (refraction, depth,
 * chromatic dispersion) -> highlight -> surface tint -> inner shadow. The lens / highlight / shadow
 * math is shared with [LiquidGlass]; the difference is that every distance is scaled from the real
 * stroke thickness of the digits (like the library scales it from the shape's smallest dimension),
 * so the refraction fills the whole stroke like a thick lens instead of only a thin edge band.
 */
object LiquidGlassReal {

    /** Half of the thickest stroke of the digits, in px. */
    fun halfStroke(alpha: IntArray, w: Int, h: Int): Float {
        val n = w * h
        val inside = BooleanArray(n) { alpha[it] >= 128 }
        val din = LiquidGlass.distanceInside(inside, w, h)
        var m = 0f
        for (v in din) if (v > m) m = v
        return max(m, 4f)
    }

    /** vibrancy: saturation boost (the library uses 1.5). */
    private fun vibrancy(fill: IntArray, sat: Float): IntArray {
        if (sat <= 1.001f) return fill
        val out = IntArray(fill.size)
        for (i in fill.indices) {
            val c = fill[i]
            val r = ((c shr 16) and 255).toFloat()
            val g = ((c shr 8) and 255).toFloat()
            val b = (c and 255).toFloat()
            val l = 0.213f * r + 0.715f * g + 0.072f * b
            val nr = (l + (r - l) * sat).roundToInt().coerceIn(0, 255)
            val ng = (l + (g - l) * sat).roundToInt().coerceIn(0, 255)
            val nb = (l + (b - l) * sat).roundToInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
        return out
    }

    fun apply(alpha: IntArray, fill: IntArray, w: Int, h: Int, s: ClockSettings): IntArray {
        val d = halfStroke(alpha, w, h)
        val vf = vibrancy(fill, 1f + s.realVibrancy / 100f)
        return LiquidGlass.apply(alpha, vf, w, h, s.gReal.toRealParams(d))
    }
}
