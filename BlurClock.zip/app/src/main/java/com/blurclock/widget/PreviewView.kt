package com.blurclock.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Wallpaper with the clock (mode 0) or the four shortcut circles (mode 1) on top.
 * Items can be dragged when [interactive]: id -1 = clock, 0..3 = circles.
 */
class PreviewView(ctx: Context, private var ratio: Float, private val interactive: Boolean) : View(ctx) {
    private var wall: Bitmap? = null
    private var clock: Bitmap? = null
    private var circles: Array<Bitmap?> = arrayOfNulls<Bitmap>(4)
    private var s: ClockSettings? = null
    private var mode = 0
    private var selected = -2
    private var lastX = 0f
    private var lastY = 0f
    var onDrag: ((Int, Float, Float) -> Unit)? = null
    var onDragEnd: (() -> Unit)? = null

    private val labels = arrayOf("F", "C", "P", "O")
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val outline = Paint().apply {
        style = Paint.Style.STROKE
        color = Color.argb(160, 255, 255, 255)
        strokeWidth = 2f
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        textAlign = Paint.Align.CENTER
        textSize = 24f
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    fun set(w: Bitmap?, c: Bitmap?, circ: Array<Bitmap?>, st: ClockSettings, m: Int) {
        val newRatio = st.wallH.toFloat() / st.wallW
        val relayout = newRatio != ratio
        ratio = newRatio
        wall = w
        clock = c
        circles = circ
        s = st
        mode = m
        if (relayout) requestLayout()
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * ratio).toInt())
    }

    private fun rectOf(id: Int, st: ClockSettings): RectF {
        val vw = width.toFloat()
        val vh = height.toFloat()
        return if (id == -1) {
            RectF(st.posX * vw, st.posY * vh, (st.posX + st.widthFrac) * vw, (st.posY + st.heightFrac) * vh)
        } else {
            RectF(
                st.cx[id] * vw, st.cy[id] * vh,
                (st.cx[id] + st.circleSize) * vw, (st.cy[id] + st.circleHFrac()) * vh
            )
        }
    }

    override fun onDraw(canvas: Canvas) {
        val st = s
        val vw = width.toFloat()
        val vh = height.toFloat()
        canvas.drawColor(0xFF2A2A2A.toInt())
        wall?.let { canvas.drawBitmap(it, null, RectF(0f, 0f, vw, vh), paint) }
        if (st == null) return
        if (mode == 0) {
            val cr = rectOf(-1, st)
            clock?.let { canvas.drawBitmap(it, null, cr, paint) }
            if (interactive) canvas.drawRect(cr, outline)
        } else {
            for (i in 0..3) {
                val r = rectOf(i, st)
                circles[i]?.let { canvas.drawBitmap(it, null, r, paint) }
                if (interactive) {
                    canvas.drawOval(r, outline)
                    canvas.drawText(labels[i], r.centerX(), r.bottom + 24f, label)
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!interactive) return false
        val st = s ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                selected = -2
                if (mode == 0) {
                    if (rectOf(-1, st).contains(e.x, e.y)) selected = -1
                } else {
                    for (id in intArrayOf(3, 2, 1, 0)) {
                        if (rectOf(id, st).contains(e.x, e.y)) {
                            selected = id
                            break
                        }
                    }
                }
                if (selected == -2) return false
                lastX = e.x
                lastY = e.y
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (selected == -2) return false
                val dx = (e.x - lastX) / width
                val dy = (e.y - lastY) / height
                lastX = e.x
                lastY = e.y
                val nx: Float
                val ny: Float
                if (selected == -1) {
                    nx = (st.posX + dx).coerceIn(0f, maxOf(0f, 1f - st.widthFrac))
                    ny = (st.posY + dy).coerceIn(0f, maxOf(0f, 1f - st.heightFrac))
                } else {
                    nx = (st.cx[selected] + dx).coerceIn(0f, maxOf(0f, 1f - st.circleSize))
                    ny = (st.cy[selected] + dy).coerceIn(0f, maxOf(0f, 1f - st.circleHFrac()))
                }
                onDrag?.invoke(selected, nx, ny)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (selected != -2) onDragEnd?.invoke()
                selected = -2
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
