package com.blurclock.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.provider.MediaStore
import android.widget.RemoteViews
import java.io.File
import kotlin.math.roundToInt

object WidgetUpdater {
    const val ACTION_TICK = "com.blurclock.widget.TICK"

    fun updateAll(ctx: Context) {
        updateClock(ctx)
        updateCircles(ctx)
    }

    /** Real size (px) of a placed widget of the given provider, or null if unknown. */
    private fun sizeOf(ctx: Context, mgr: AppWidgetManager, id: Int): Pair<Int, Int>? {
        val opt = mgr.getAppWidgetOptions(id)
        val density = ctx.resources.displayMetrics.density
        val w = (opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0) * density).roundToInt()
        val h = (opt.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0) * density).roundToInt()
        return if (w > 0 && h > 0) Pair(w, h) else null
    }

    fun hostSize(ctx: Context, cls: Class<*>): Pair<Int, Int>? {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
        if (ids.isEmpty()) return null
        return sizeOf(ctx, mgr, ids[0])
    }

    fun updateClock(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
        if (ids.isEmpty()) {
            cancel(ctx)
            return
        }
        val s = ClockSettings(ctx)
        val fill = if (s.blurOn || s.colorOn || s.realGlassActive()) loadFill(s.fillFile()) else null
        val dateFill = if (s.dateBlurOn) loadFill(s.dateFillFile()) else null
        val cache = HashMap<String, Bitmap>()
        for (id in ids) {
            val sz = sizeOf(ctx, mgr, id)
            val key = if (sz != null) "${sz.first}x${sz.second}" else "default"
            val bmp = cache.getOrPut(key) {
                if (sz != null) ClockRenderer.render(ctx, s, fill, dateFill, s.gClock.on, sz.first, sz.second)
                else ClockRenderer.render(ctx, s, fill, dateFill)
            }
            // No click intent on the clock: tapping it does nothing.
            val rv = RemoteViews(ctx.packageName, R.layout.widget)
            rv.setImageViewBitmap(R.id.img, bmp)
            mgr.updateAppWidget(id, rv)
        }
        schedule(ctx)
    }

    fun updateCircles(ctx: Context) {
        val mgr = AppWidgetManager.getInstance(ctx)
        val s = ClockSettings(ctx)
        val table = listOf(
            FlashlightWidgetProvider::class.java to 0,
            CameraWidgetProvider::class.java to 1,
            PhoneWidgetProvider::class.java to 2,
            CustomCircleWidgetProvider::class.java to 3
        )
        for ((cls, idx) in table) {
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, cls))
            if (ids.isEmpty()) continue
            val fill = loadFill(s.circleFillFile(idx))
            val logo = s.loadLogo(idx)
            val pi = clickFor(ctx, s, idx)
            for (id in ids) {
                val sz = sizeOf(ctx, mgr, id)
                val bmp = if (sz != null) {
                    CircleRenderer.render(s, idx, fill, logo, true, sz.first, sz.second)
                } else {
                    CircleRenderer.render(s, idx, fill, logo, true)
                }
                val rv = RemoteViews(ctx.packageName, R.layout.widget_circle)
                rv.setImageViewBitmap(R.id.img, bmp)
                if (pi != null) rv.setOnClickPendingIntent(R.id.img, pi)
                mgr.updateAppWidget(id, rv)
            }
        }
    }

    /**
     * Flashlight: toggles the torch. Others: if a package is set, open that app
     * (with the class name if given), otherwise camera / dialer defaults; custom does nothing.
     */
    private fun clickFor(ctx: Context, s: ClockSettings, idx: Int): PendingIntent? {
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        if (idx == 0) {
            return PendingIntent.getBroadcast(ctx, 11, Intent(ctx, TorchReceiver::class.java), flags)
        }
        val pkg = s.pkg[idx].trim()
        val cls = s.cls[idx].trim()
        var intent: Intent? = null
        if (pkg.isNotEmpty()) {
            intent = if (cls.isNotEmpty()) {
                val full = if (cls.startsWith(".")) pkg + cls else cls
                Intent().setClassName(pkg, full)
            } else {
                ctx.packageManager.getLaunchIntentForPackage(pkg)
            }
        } else if (idx == 1) {
            intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        } else if (idx == 2) {
            intent = Intent(Intent.ACTION_DIAL)
        }
        if (intent == null) return null
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, 11 + idx, intent, flags)
    }

    private fun loadFill(f: File): Bitmap? {
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
    }

    private fun pending(ctx: Context): PendingIntent {
        val i = Intent(ctx, ClockWidgetProvider::class.java).setAction(ACTION_TICK)
        return PendingIntent.getBroadcast(ctx, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val t = (System.currentTimeMillis() / 60000 + 1) * 60000 + 300
        val pi = pending(ctx)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC, t, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC, t, pi)
        }
    }

    fun cancel(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(ctx))
    }
}
