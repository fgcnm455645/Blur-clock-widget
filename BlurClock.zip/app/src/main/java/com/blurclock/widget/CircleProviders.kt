package com.blurclock.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper

abstract class CircleProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        WidgetUpdater.updateCircles(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        WidgetUpdater.updateCircles(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            WidgetUpdater.updateCircles(context)
        }
    }
}

class FlashlightWidgetProvider : CircleProvider()
class CameraWidgetProvider : CircleProvider()
class PhoneWidgetProvider : CircleProvider()
class CustomCircleWidgetProvider : CircleProvider()

/** Toggles the flashlight; no activity is opened and no permission is needed. */
class TorchReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        try {
            val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            val pending = goAsync()
            val handler = Handler(Looper.getMainLooper())
            var done = false
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId != id || done) return
                    done = true
                    try {
                        cm.unregisterTorchCallback(this)
                        cm.setTorchMode(id, !enabled)
                    } catch (e: Exception) {
                    }
                    try {
                        pending.finish()
                    } catch (e: Exception) {
                    }
                }
            }
            cm.registerTorchCallback(cb, handler)
            handler.postDelayed({
                if (!done) {
                    done = true
                    try {
                        cm.unregisterTorchCallback(cb)
                        pending.finish()
                    } catch (e: Exception) {
                    }
                }
            }, 2000)
        } catch (e: Exception) {
        }
    }
}
