package com.blurclock.widget

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/*
 * Liquid glass for arbitrary shapes (the clock digits).
 *
 * The refraction curve, chromatic dispersion, directional highlight, ambient highlight and inner
 * shadow are ported from AndroidLiquidGlass (Backdrop) by Kyant,
 * Copyright 2025 Kyant, licensed under the Apache License, Version 2.0
 * (http://www.apache.org/licenses/LICENSE-2.0).
 * The original AGSL shaders work on rounded rectangles; here the same math runs on the CPU
 * using a distance field computed from the shape of the text.
 */
object LiquidGlass {

    class Params(
        val refrHeight: Float,    // px, how far from the edge the refraction reaches
        val refrAmount: Float,    // px, maximum displacement at the edge
        val depth: Boolean,
        val chroma: Boolean,
        val hlStrength: Float,    // 0..1
        val hlAngleDeg: Float,
        val hlFalloff: Float,
        val hlWidth: Float,       // px
        val ambient: Float,       // 0..1
        val shadow: Float,        // 0..1 darkness
        val shadowRadius: Float,  // px
        val shadowOffset: Float   // px
    )

    /**
     * alpha: text mask alpha (0..255); fill: ARGB pixels of the blurred backdrop (same size).
     * Returns ARGB pixels (non-premultiplied).
     */
    fun apply(alpha: IntArray, fill: IntArray, w: Int, h: Int, p: Params): IntArray {
        val n = w * h
        val out = IntArray(n)

        var minX = w
        var maxX = -1
        var minY = h
        var maxY = -1
        val inside = BooleanArray(n)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                if (alpha[row + x] >= 128) {
                    inside[row + x] = true
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }
        if (maxX < 0) return out
        val cxm = (minX + maxX) / 2f
        val cym = (minY + maxY) / 2f
        val halfW = max(1f, (maxX - minX) / 2f)
        val halfH = max(1f, (maxY - minY) / 2f)

        val din = distanceInside(inside, w, h)
        // smoothed copy, only used for the normals (gives clean, continuous edges)
        val ds = din.copyOf()
        repeat(2) { boxBlurFloat(ds, w, h) }

        val shadowField = if (p.shadow > 0f) innerShadowField(alpha, w, h, p) else null

        val refrH = max(p.refrHeight, 0.001f)
        val bandW = max(p.hlWidth, 0.001f)
        val maxD = max(refrH, bandW)
        val ang = Math.toRadians(p.hlAngleDeg.toDouble())
        val nlx = cos(ang).toFloat()
        val nly = kotlin.math.sin(ang).toFloat()
        val doRefr = p.refrAmount > 0f
        val rgb = FloatArray(3)

        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val i = row + x
                val a = alpha[i]
                if (a == 0) continue
                val dd = din[i]

                // outward unit normal from the distance field
                var gx = 0f
                var gy = 0f
                if (dd < maxD) {
                    val xm = max(x - 1, 0)
                    val xp = min(x + 1, w - 1)
                    val ym = max(y - 1, 0)
                    val yp = min(y + 1, h - 1)
                    val sx = (ds[ym * w + xp] + 2f * ds[row + xp] + ds[yp * w + xp]) -
                        (ds[ym * w + xm] + 2f * ds[row + xm] + ds[yp * w + xm])
                    val sy = (ds[yp * w + xm] + 2f * ds[yp * w + x] + ds[yp * w + xp]) -
                        (ds[ym * w + xm] + 2f * ds[ym * w + x] + ds[ym * w + xp])
                    val ix = -sx / 8f
                    val iy = -sy / 8f
                    val len = hypot(ix, iy)
                    if (len > 1e-4f) {
                        gx = ix / len
                        gy = iy / len
                    }
                }

                var r: Float
                var g: Float
                var b: Float
                val base = fill[i]

                if (doRefr && dd < refrH) {
                    val x01 = (1f - dd / refrH).coerceIn(0f, 1f)
                    val circle = 1f - sqrt(max(0f, 1f - x01 * x01))
                    val dsh = circle * p.refrAmount
                    var ux = gx
                    var uy = gy
                    if (p.depth) {
                        val cxv = x - cxm
                        val cyv = y - cym
                        val cl = hypot(cxv, cyv)
                        if (cl > 1e-4f) {
                            ux += cxv / cl
                            uy += cyv / cl
                        }
                        val ul = hypot(ux, uy)
                        if (ul > 1e-4f) {
                            ux /= ul
                            uy /= ul
                        } else {
                            ux = 0f
                            uy = 0f
                        }
                    }
                    val rx = x - dsh * ux
                    val ry = y - dsh * uy
                    if (p.chroma) {
                        val di = ((x - cxm) * (y - cym)) / (halfW * halfH)
                        val dx = -dsh * ux * di
                        val dy = -dsh * uy * di
                        var rr = 0f
                        var gg = 0f
                        var bb = 0f
                        // red
                        sample(fill, w, h, rx + dx, ry + dy, rgb)
                        rr += rgb[0] / 3.5f
                        // orange
                        sample(fill, w, h, rx + dx * (2f / 3f), ry + dy * (2f / 3f), rgb)
                        rr += rgb[0] / 3.5f
                        gg += rgb[1] / 7f
                        // yellow
                        sample(fill, w, h, rx + dx * (1f / 3f), ry + dy * (1f / 3f), rgb)
                        rr += rgb[0] / 3.5f
                        gg += rgb[1] / 3.5f
                        // green
                        sample(fill, w, h, rx, ry, rgb)
                        gg += rgb[1] / 3.5f
                        // cyan
                        sample(fill, w, h, rx - dx * (1f / 3f), ry - dy * (1f / 3f), rgb)
                        gg += rgb[1] / 3.5f
                        bb += rgb[2] / 3f
                        // blue
                        sample(fill, w, h, rx - dx * (2f / 3f), ry - dy * (2f / 3f), rgb)
                        bb += rgb[2] / 3f
                        // purple
                        sample(fill, w, h, rx - dx, ry - dy, rgb)
                        rr += rgb[0] / 7f
                        bb += rgb[2] / 3f
                        r = rr
                        g = gg
                        b = bb
                    } else {
                        sample(fill, w, h, rx, ry, rgb)
                        r = rgb[0]
                        g = rgb[1]
                        b = rgb[2]
                    }
                } else {
                    r = ((base shr 16) and 255).toFloat()
                    g = ((base shr 8) and 255).toFloat()
                    b = (base and 255).toFloat()
                }

                // inner shadow (darkens the inside of the top edges)
                if (shadowField != null) {
                    val sa = shadowField[i] / 255f * p.shadow
                    val k = 1f - sa
                    r *= k
                    g *= k
                    b *= k
                }

                if (dd < bandW) {
                    val band = ((bandW - dd) / (bandW * 0.5f)).coerceIn(0f, 1f)
                    val dp = gx * nlx + gy * nly
                    // ambient highlight: only the half of the edge facing the light
                    if (p.ambient > 0f && dp > 0f) {
                        val m = p.ambient * dp * band
                        r += (255f - r) * m
                        g += (255f - g) * m
                        b += (255f - b) * m
                    }
                    // directional highlight, added on top
                    if (p.hlStrength > 0f) {
                        val add = p.hlStrength * abs(dp).pow(p.hlFalloff) * band * 255f
                        r += add
                        g += add
                        b += add
                    }
                }

                out[i] = (a shl 24) or
                    (r.roundToInt().coerceIn(0, 255) shl 16) or
                    (g.roundToInt().coerceIn(0, 255) shl 8) or
                    b.roundToInt().coerceIn(0, 255)
            }
        }
        return out
    }

    /** Bilinear sample of the backdrop; writes r, g, b (0..255) into out. */
    private fun sample(fill: IntArray, w: Int, h: Int, xf: Float, yf: Float, out: FloatArray) {
        val x = xf.coerceIn(0f, w - 1.001f)
        val y = yf.coerceIn(0f, h - 1.001f)
        val x0 = floor(x).toInt()
        val y0 = floor(y).toInt()
        val tx = x - x0
        val ty = y - y0
        val a = fill[y0 * w + x0]
        val b = fill[y0 * w + x0 + 1]
        val c = fill[(y0 + 1) * w + x0]
        val d = fill[(y0 + 1) * w + x0 + 1]
        for (ch in 0..2) {
            val sh = 16 - 8 * ch
            val va = ((a shr sh) and 255).toFloat()
            val vb = ((b shr sh) and 255).toFloat()
            val vc = ((c shr sh) and 255).toFloat()
            val vd = ((d shr sh) and 255).toFloat()
            out[ch] = (va * (1f - tx) + vb * tx) * (1f - ty) + (vc * (1f - tx) + vd * tx) * ty
        }
    }

    /** Distance (px) from every inside pixel to the nearest outside pixel; 0 for outside pixels. */
    internal fun distanceInside(inside: BooleanArray, w: Int, h: Int): FloatArray {
        val inf = 1e8f
        val f = FloatArray(w * h) { if (inside[it]) inf else 0f }
        val len = max(w, h)
        val line = FloatArray(len)
        val res = FloatArray(len)
        val v = IntArray(len)
        val z = FloatArray(len + 1)
        for (x in 0 until w) {
            for (y in 0 until h) line[y] = f[y * w + x]
            dt1(line, res, h, v, z)
            for (y in 0 until h) f[y * w + x] = res[y]
        }
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) line[x] = f[row + x]
            dt1(line, res, w, v, z)
            for (x in 0 until w) f[row + x] = res[x]
        }
        for (i in f.indices) f[i] = sqrt(f[i])
        return f
    }

    /** 1D squared distance transform (Felzenszwalb & Huttenlocher). */
    private fun dt1(f: FloatArray, d: FloatArray, n: Int, v: IntArray, z: FloatArray) {
        val inf = 1e20f
        var k = 0
        v[0] = 0
        z[0] = -inf
        z[1] = inf
        for (q in 1 until n) {
            var s = ((f[q] + q.toFloat() * q) - (f[v[k]] + v[k].toFloat() * v[k])) / (2f * q - 2f * v[k])
            while (s <= z[k]) {
                k--
                s = ((f[q] + q.toFloat() * q) - (f[v[k]] + v[k].toFloat() * v[k])) / (2f * q - 2f * v[k])
            }
            k++
            v[k] = q
            z[k] = s
            z[k + 1] = inf
        }
        k = 0
        for (q in 0 until n) {
            while (z[k + 1] < q) k++
            val dq = (q - v[k]).toFloat()
            d[q] = dq * dq + f[v[k]]
        }
    }

    /** 3x3 box blur, in place. */
    private fun boxBlurFloat(a: FloatArray, w: Int, h: Int) {
        val tmp = FloatArray(a.size)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                val l = a[row + max(x - 1, 0)]
                val c = a[row + x]
                val r = a[row + min(x + 1, w - 1)]
                tmp[row + x] = (l + c + r) / 3f
            }
        }
        for (y in 0 until h) {
            val up = max(y - 1, 0) * w
            val dn = min(y + 1, h - 1) * w
            val row = y * w
            for (x in 0 until w) {
                a[row + x] = (tmp[up + x] + tmp[row + x] + tmp[dn + x]) / 3f
            }
        }
    }

    /** Blurred "outside" mask shifted downwards: darkens the inside of the top edges. */
    private fun innerShadowField(alpha: IntArray, w: Int, h: Int, p: Params): IntArray {
        val field = IntArray(w * h)
        val off = p.shadowOffset.roundToInt()
        for (y in 0 until h) {
            val sy = y - off
            val row = y * w
            for (x in 0 until w) {
                field[row + x] = if (sy < 0 || sy >= h) 255 else 255 - alpha[sy * w + x]
            }
        }
        val r = max(1, (p.shadowRadius * 0.5f).roundToInt())
        repeat(2) {
            blur1(field, w, h, r, true)
            blur1(field, w, h, r, false)
        }
        return field
    }

    private fun blur1(px: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        val tmp = IntArray(len)
        for (line in 0 until lines) {
            val start = if (horizontal) line * w else line
            var sum = 0
            for (i in -r..r) sum += px[start + i.coerceIn(0, len - 1) * step]
            for (x in 0 until len) {
                tmp[x] = sum / div
                sum += px[start + min(x + r + 1, len - 1) * step] - px[start + max(x - r, 0) * step]
            }
            for (x in 0 until len) px[start + x * step] = tmp[x]
        }
    }
}
