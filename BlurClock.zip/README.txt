Blur Clock - tall lock screen clock + blurred shortcut circles

Liquid glass: the refraction, chromatic dispersion, highlight and inner shadow math is ported from
AndroidLiquidGlass (Backdrop) by Kyant, Copyright 2025 Kyant, licensed under the Apache License 2.0
(http://www.apache.org/licenses/LICENSE-2.0).
