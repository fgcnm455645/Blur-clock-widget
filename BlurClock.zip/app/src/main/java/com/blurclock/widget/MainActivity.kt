package com.blurclock.widget

import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.content.res.ColorStateList
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.HorizontalScrollView
import android.widget.PopupMenu
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs
import kotlin.math.ceil

class MainActivity : Activity() {
    private lateinit var s: ClockSettings
    private lateinit var preview: PreviewView
    private lateinit var overlayPreview: PreviewView
    private lateinit var overlayLayer: FrameLayout
    private lateinit var overlayLabel: TextView
    private lateinit var clockPanel: LinearLayout
    private lateinit var shortPanel: LinearLayout
    private lateinit var modeButtons: Array<Button>
    private lateinit var formatButton: Button
    private lateinit var langButton: Button
    private var colorSwatches: List<View> = emptyList()
    private var shadeBar: SeekBar? = null

    private val walls = arrayOfNulls<Bitmap>(2)
    private var mode = 0
    private var clockBmp: Bitmap? = null
    private var lastFill: Bitmap? = null
    private var lastDateFill: Bitmap? = null
    private val circleBmps = arrayOfNulls<Bitmap>(4)
    private val logos = arrayOfNulls<Bitmap>(4)

    // liquid glass for the clock is heavy, so it is rendered on a background thread (one at a time)
    private var gen = 0
    private var busy = false
    private var dirty = false

    private var importing = false
    private var pendingLockImportMode = -1
    private var pendingWallMode = 0

    private val REQ_WALL = 1
    private val REQ_CLOCK_FONT = 2
    private val REQ_DATE_FONT = 3
    private val REQ_LOGO = 100   // 100..103

    private class Cap(val header: TextView, val body: LinearLayout, val title: String)

    private fun t(en: String, fa: String) = if (s.lang == "fa") fa else en
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupFullscreen()
        s = ClockSettings(this)
        mode = if (s.mode == 1) 1 else 0
        loadWalls()
        for (i in 0..3) logos[i] = s.loadLogo(i)

        val frame = FrameLayout(this)
        val scroll = ScrollView(this)
        scroll.clipToPadding = false
        scroll.setBackgroundColor(0xFF101012.toInt())
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(14), dp(14), dp(40))
        scroll.addView(col)

        // ---- full-screen preview shown while a slider is being touched ----
        overlayLayer = FrameLayout(this)
        overlayLayer.setBackgroundColor(0xF0000000.toInt())
        overlayLayer.visibility = View.GONE
        val ratio = s.wallH.toFloat() / s.wallW
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val ow = minOf((screenW * 0.9f).toInt(), (screenH * 0.86f / ratio).toInt())
        overlayPreview = PreviewView(this, ratio, false)
        val olp = FrameLayout.LayoutParams(ow, ViewGroup.LayoutParams.WRAP_CONTENT)
        olp.gravity = Gravity.CENTER_HORIZONTAL or Gravity.TOP
        olp.topMargin = dp(24)
        overlayLayer.addView(overlayPreview, olp)
        overlayLabel = TextView(this)
        overlayLabel.setTextColor(Color.WHITE)
        overlayLabel.textSize = 16f
        overlayLabel.gravity = Gravity.CENTER
        overlayLabel.setBackgroundColor(0xAA000000.toInt())
        overlayLabel.setPadding(dp(12), dp(10), dp(12), dp(10))
        val llp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        llp.gravity = Gravity.BOTTOM
        overlayLayer.addView(overlayLabel, llp)
        frame.addView(overlayLayer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- main preview (drag the clock / circles here) ----
        preview = PreviewView(this, ratio, true)
        val pw = (screenW * 0.5f).toInt()
        val plp = LinearLayout.LayoutParams(pw, ViewGroup.LayoutParams.WRAP_CONTENT)
        plp.gravity = Gravity.CENTER_HORIZONTAL
        col.addView(preview, plp)
        preview.onDrag = { id, x, y ->
            if (id == -1) {
                s.posX = x
                s.posY = y
            } else {
                s.cx[id] = x
                s.cy[id] = y
            }
            refresh(true)   // no glass while dragging, to keep it smooth
        }
        preview.onDragEnd = { refresh() }

        addNote(col, t("Drag the clock / circles on the preview to find a good blur spot.", "ساعت یا دایره‌ها رو روی پیش‌نمایش بکش تا جای مناسب بلر رو پیدا کنی."))

        addButton(col, t("Save and apply to widget", "ثبت و اعمال روی ویجت")) { applyMode(mode, false) }

        // ---- [time format] [clock] [shortcuts] [language] ----
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        formatButton = Button(this)
        formatButton.setOnClickListener { showFormatMenu() }
        val b0 = Button(this)
        b0.text = t("Clock", "ساعت")
        b0.setOnClickListener { setMode(0) }
        val b1 = Button(this)
        b1.text = t("Shortcuts", "شورتکات‌ها")
        b1.setOnClickListener { setMode(1) }
        langButton = Button(this)
        langButton.text = if (s.lang == "fa") "EN" else "FA"
        langButton.setOnClickListener {
            s.lang = if (s.lang == "fa") "en" else "fa"
            s.save()
            recreate()
        }
        modeButtons = arrayOf(b0, b1)
        for (b in arrayOf(formatButton, b0, b1, langButton)) {
            b.isAllCaps = false
            b.textSize = 13f
            b.minWidth = 0
            b.minimumWidth = 0
            b.minHeight = 0
            b.minimumHeight = 0
            b.setPadding(dp(4), dp(9), dp(4), dp(9))
            b.setTextColor(Color.WHITE)
            b.maxLines = 1
        }
        styleButton(formatButton, false)
        styleButton(langButton, false)
        updateFormatButton()
        fun cell(b: Button, weight: Float, first: Boolean) {
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
            if (!first) lp.marginStart = dp(4)
            row.addView(b, lp)
        }
        cell(formatButton, 1.25f, true)
        cell(b0, 1.25f, false)
        cell(b1, 1.6f, false)
        cell(langButton, 0.8f, false)
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(6)
        col.addView(row, rlp)

        clockPanel = LinearLayout(this)
        clockPanel.orientation = LinearLayout.VERTICAL
        shortPanel = LinearLayout(this)
        shortPanel.orientation = LinearLayout.VERTICAL
        col.addView(clockPanel)
        col.addView(shortPanel)
        buildClockPanel(clockPanel)
        buildShortcutPanel(shortPanel)

        val sysGroup = ArrayList<Cap>()
        addCapsule(col, sysGroup, t("System", "سیستم"), false) { body ->
            addButton(body, t("Allow exact alarms (per-minute updates)", "اجازه آلارم دقیق (برای آپدیت هر دقیقه)")) {
                if (Build.VERSION.SDK_INT >= 31) {
                    try {
                        startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                    } catch (e: Exception) {
                        toast(t("Not found on this device", "این گزینه در دستگاه پیدا نشد"))
                    }
                } else toast(t("Not needed on this Android version", "نیازی نیست"))
            }
            addButton(body, t("Battery optimization settings", "تنظیمات بهینه‌سازی باتری")) {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: ActivityNotFoundException) {
                    toast(t("Not found on this device", "این گزینه در دستگاه پیدا نشد"))
                }
            }
        }

        setContentView(frame)
        frame.setOnApplyWindowInsetsListener { _, ins ->
            var top = 0
            var bottom = 0
            if (Build.VERSION.SDK_INT >= 30) {
                top = ins.getInsetsIgnoringVisibility(WindowInsets.Type.statusBars() or WindowInsets.Type.displayCutout()).top
                bottom = ins.getInsets(WindowInsets.Type.ime()).bottom
            } else {
                top = ins.stableInsetTop
                val cut = ins.displayCutout
                if (cut != null) top = maxOf(top, cut.safeInsetTop)
                bottom = ins.systemWindowInsetBottom
            }
            col.setPadding(dp(14), dp(14) + top, dp(14), dp(40))
            scroll.setPadding(0, 0, 0, bottom)
            (overlayPreview.layoutParams as? FrameLayout.LayoutParams)?.let {
                it.topMargin = dp(24) + top
                overlayPreview.layoutParams = it
            }
            ins
        }
        frame.requestApplyInsets()
        setModeUi()
        refresh()
    }

    /** Full screen: content under the cutout, status and navigation bars hidden (swipe from the edge to show them). */
    private fun setupFullscreen() {
        window.setBackgroundDrawable(ColorDrawable(0xFF101012.toInt()))
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            } else {
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
            window.attributes = lp
        }
        hideBars()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onResume() {
        super.onResume()
        if (!::preview.isInitialized) return
        syncHostSize()
        if (pendingLockImportMode >= 0) {
            val m = pendingLockImportMode
            pendingLockImportMode = -1
            importLockWallpaper(m, force = true, auto = false, onDone = null)
        } else {
            val list = (0..1).filter { s.autoSync[it] }
            if (list.isNotEmpty()) {
                fun step(i: Int) {
                    if (i >= list.size) return
                    importLockWallpaper(list[i], force = false, auto = true) { step(i + 1) }
                }
                step(0)
            }
        }
    }

    // ------------------------------------------------------------------ panels

    private fun buildClockPanel(panel: LinearLayout) {
        val g = ArrayList<Cap>()

        addCapsule(panel, g, t("Wallpaper", "والپیپر"), true) { body ->
            addWallpaperControls(body, 0)
        }

        addCapsule(panel, g, t("Clock blur", "بلر ساعت"), false) { body ->
            addSwitch(body, t("Blur enabled (off = plain white digits)", "بلر فعال (غیرفعال = اعداد کاملا سفید)"), s.blurOn) {
                s.blurOn = it
                refresh()
            }
            addSlider(body, t("Clock blur amount", "میزان بلر ساعت"), 0f, 100f, s.blur.toFloat(), { it.toInt().toString() }) {
                s.blur = it.toInt()
                refresh()
            }
            addSlider(body, t("Clock whiteness", "سفیدی ساعت"), 0f, 100f, s.white.toFloat(), { it.toInt().toString() }) {
                s.white = it.toInt()
                refresh()
            }
        }

        addCapsule(panel, g, t("Color blur", "کالر بلر (رنگی)"), false) { body ->
            addNote(body, t("Tints the clock with a color on top of the blurred wallpaper (like the lock screen apps).", "ساعت رو با یک رنگ روی والپیپر بلر شده رنگی می‌کنه (مثل اپ‌های لاک‌اسکرین)."))
            addSwitch(body, t("Color blur enabled", "کالر بلر فعال"), s.colorOn) {
                s.colorOn = it
                refresh()
            }
            addColorSwatches(body)
            addSlider(
                body, t("Color shade (light to dark)", "سایه رنگ (روشن به تیره)"),
                0f, 100f, s.colorShade.toFloat(), { it.toInt().toString() },
                bar = { sb ->
                    shadeBar = sb
                    updateShadeBar()
                }
            ) {
                s.colorShade = it.toInt()
                updateShadeBar()
                refresh()
            }
            addSlider(body, t("Color strength", "شدت رنگ"), 0f, 100f, s.colorStrength.toFloat(), { it.toInt().toString() }) {
                s.colorStrength = it.toInt()
                refresh()
            }
            addSegment(body, listOf("Glass", "Solid"), if (s.colorSolid) 1 else 0) {
                s.colorSolid = it == 1
                refresh()
            }
            addSwitch(body, t("Use the same color for the date", "همین رنگ برای تاریخ هم استفاده بشه"), s.colorDate) {
                s.colorDate = it
                refresh()
            }
        }

        addCapsule(panel, g, t("Bottom fade", "محو شدگی پایین ساعت"), false) { body ->
            addNote(body, t("Fades the digits out towards the bottom (like the KWGT gradient FX).", "اعداد ساعت رو به سمت پایین محو می‌کنه (مثل گرادینت FX توی KWGT)."))
            addSwitch(body, t("Fade enabled", "محو شدگی فعال"), s.fadeOn) {
                s.fadeOn = it
                refresh()
            }
            addSlider(body, t("Width (size of the fade zone)", "Width (اندازه ناحیه محو شدگی)"), 1f, 100f, s.fadeWidth.toFloat(), { it.toInt().toString() }) {
                s.fadeWidth = it.toInt()
                refresh()
            }
            addSlider(body, t("Offset (where the fade is centered)", "Offset (مرکز محو شدگی)"), 0f, 100f, s.fadeOffset.toFloat(), { it.toInt().toString() }) {
                s.fadeOffset = it.toInt()
                refresh()
            }
        }

        addCapsule(panel, g, t("Date blur", "بلر تاریخ"), false) { body ->
            addSwitch(body, t("Date blur enabled (off = plain white date)", "بلر تاریخ فعال (غیرفعال = تاریخ کاملا سفید)"), s.dateBlurOn) {
                s.dateBlurOn = it
                refresh()
            }
            addSlider(body, t("Date blur amount", "میزان بلر تاریخ"), 0f, 100f, s.dateBlur.toFloat(), { it.toInt().toString() }) {
                s.dateBlur = it.toInt()
                refresh()
            }
            addSlider(body, t("Date whiteness", "سفیدی تاریخ"), 0f, 100f, s.dateWhite.toFloat(), { it.toInt().toString() }) {
                s.dateWhite = it.toInt()
                refresh()
            }
        }

        addCapsule(panel, g, t("Clock liquid glass", "لیکوید گلس ساعت"), false) { body ->
            addNote(body, t("Needs the clock blur (or color blur) to be on. The new effect uses math from the Backdrop library (Kyant, Apache 2.0).", "فقط وقتی بلر یا کالر بلر ساعت روشنه کار می‌کنه. افکت جدید از ریاضی کتابخونه Backdrop (Kyant، Apache 2.0) استفاده می‌کنه."))
            addSwitch(body, t("Liquid glass enabled", "لیکوید گلس فعال"), s.gClock.on) {
                s.gClock.on = it
                refresh()
            }
            val newBox = LinearLayout(this)
            newBox.orientation = LinearLayout.VERTICAL
            val oldBox = LinearLayout(this)
            oldBox.orientation = LinearLayout.VERTICAL
            val realBox = LinearLayout(this)
            realBox.orientation = LinearLayout.VERTICAL
            fun showBox(i: Int) {
                newBox.visibility = if (i == 0) View.VISIBLE else View.GONE
                oldBox.visibility = if (i == 1) View.VISIBLE else View.GONE
                realBox.visibility = if (i == 2) View.VISIBLE else View.GONE
            }
            showBox(s.glassType)
            addSegment(body, listOf(t("New", "جدید"), t("Old", "قدیمی"), t("Real", "واقعی")), s.glassType) {
                s.glassType = it
                showBox(it)
                refresh()
            }
            body.addView(newBox)
            body.addView(oldBox)
            body.addView(realBox)
            addGlassControls(newBox, s.gClock, false)
            addNote(realBox, t("Real: thick-lens glass. Sizes follow the thickness of the digit strokes. It uses its own blur and tint below instead of the clock blur.", "واقعی: شیشه ضخیم مثل عدسی. اندازه‌ها از ضخامت خط اعداد حساب می‌شن و به‌جای بلر ساعت، بلر و رنگ خودش (پایین) رو استفاده می‌کنه."))
            addSlider(realBox, t("Backdrop blur inside the glass", "بلر پس‌زمینه داخل شیشه"), 0f, 100f, s.realBlur.toFloat(), { it.toInt().toString() }) {
                s.realBlur = it.toInt()
                refresh()
            }
            addSlider(realBox, t("Surface tint (white)", "رنگ سطح شیشه (سفید)"), 0f, 100f, s.realTint.toFloat(), { it.toInt().toString() }) {
                s.realTint = it.toInt()
                refresh()
            }
            addSlider(realBox, t("Vibrancy (saturation boost)", "ویبرنسی (افزایش رنگ)"), 0f, 100f, s.realVibrancy.toFloat(), { it.toInt().toString() }) {
                s.realVibrancy = it.toInt()
                refresh()
            }
            addGlassControls(realBox, s.gReal, false)
            addSlider(oldBox, t("Refraction", "شکست نور"), 0f, 100f, s.oldRefr.toFloat(), { it.toInt().toString() }) {
                s.oldRefr = it.toInt()
                refresh()
            }
            addSlider(oldBox, t("Gloss", "براقی"), 0f, 100f, s.oldGloss.toFloat(), { it.toInt().toString() }) {
                s.oldGloss = it.toInt()
                refresh()
            }
        }

        addCapsule(panel, g, t("Size and layout", "اندازه و ابعاد"), false) { body ->
            addSlider(body, t("Clock size", "اندازه ساعت"), 0.1f, 2.0f, s.clockSize, { "%.2f".format(it) }) {
                s.clockSize = it
                refresh()
            }
            addSlider(body, t("Clock digit width (horizontal stretch)", "عرض اعداد ساعت (کشیدگی افقی)"), 0.2f, 2.0f, s.clockScaleX, { "%.2f".format(it) }) {
                s.clockScaleX = it
                refresh()
            }
            addSlider(body, t("Date size", "اندازه تاریخ"), 0.02f, 0.15f, s.dateSize, { "%.3f".format(it) }) {
                s.dateSize = it
                refresh()
            }
            addSlider(body, t("Gap between date and clock", "فاصله تاریخ تا ساعت"), -0.05f, 0.1f, s.gap, { "%.3f".format(it) }) {
                s.gap = it
                refresh()
            }
            val manual = LinearLayout(this)
            manual.orientation = LinearLayout.VERTICAL
            manual.visibility = if (s.followSize) View.GONE else View.VISIBLE
            addSwitch(body, t("Follow the placed widget's size (recommended, keeps the image sharp)", "پیروی از اندازه ویجت روی هوم/لاک (پیشنهادی، تصویر تیز می‌مونه)"), s.followSize) {
                s.followSize = it
                manual.visibility = if (it) View.GONE else View.VISIBLE
                s.save()
                if (it) syncHostSize()
            }
            body.addView(manual)
            addSlider(manual, t("Widget width (fraction of screen)", "عرض ویجت (درصد صفحه)"), 0.3f, 1.0f, s.widthFrac, { "%.2f".format(it) }) {
                s.widthFrac = it
                refresh()
            }
            addSlider(manual, t("Widget height (fraction of screen)", "ارتفاع ویجت (درصد صفحه)"), 0.1f, 0.7f, s.heightFrac, { "%.2f".format(it) }) {
                s.heightFrac = it
                refresh()
            }
        }

        addCapsule(panel, g, t("Fonts", "فونت‌ها"), false) { body ->
            addButton(body, t("Choose clock font (ttf / otf)", "انتخاب فونت ساعت (ttf / otf)")) { pick("*/*", REQ_CLOCK_FONT) }
            addButton(body, t("Choose date font (ttf / otf)", "انتخاب فونت تاریخ (ttf / otf)")) { pick("*/*", REQ_DATE_FONT) }
            addButton(body, t("Reset fonts to default", "فونت‌ها به حالت پیش‌فرض")) {
                Fonts.reset(this)
                refresh()
            }
        }
    }

    private fun buildShortcutPanel(panel: LinearLayout) {
        val g = ArrayList<Cap>()
        val names = arrayOf(
            t("Flashlight (F)", "چراغ قوه (F)"), t("Camera (C)", "دوربین (C)"),
            t("Phone (P)", "تماس (P)"), t("Custom (O)", "سفارشی (O)")
        )

        addCapsule(panel, g, t("Shortcut wallpaper", "والپیپر شورتکات"), true) { body ->
            addWallpaperControls(body, 1)
        }

        addCapsule(panel, g, t("Circle look", "ظاهر دایره‌ها"), false) { body ->
            addSlider(body, t("Circle size", "اندازه دایره‌ها"), 0.08f, 0.3f, s.circleSize, { "%.3f".format(it) }) {
                s.circleSize = it
                refresh()
            }
            addSlider(body, t("Blur amount", "میزان بلر"), 0f, 100f, s.circleBlur.toFloat(), { it.toInt().toString() }) {
                s.circleBlur = it.toInt()
                refresh()
            }
            addSlider(body, t("Whiteness", "سفیدی"), 0f, 100f, s.circleWhite.toFloat(), { it.toInt().toString() }) {
                s.circleWhite = it.toInt()
                refresh()
            }
            addSlider(body, t("Darkness", "تیرگی"), 0f, 100f, s.circleDark.toFloat(), { it.toInt().toString() }) {
                s.circleDark = it.toInt()
                refresh()
            }
            addSwitch(body, t("White frame around the circle", "فریم سفید دور دایره"), s.frameOn) {
                s.frameOn = it
                refresh()
            }
            addSlider(body, t("Frame thickness", "ضخامت فریم"), 0.01f, 0.12f, s.frameThick, { "%.3f".format(it) }) {
                s.frameThick = it
                refresh()
            }
            addSlider(body, t("Frame opacity", "شفافیت فریم"), 0f, 100f, s.frameAlpha.toFloat(), { it.toInt().toString() }) {
                s.frameAlpha = it.toInt()
                refresh()
            }
        }

        addCapsule(panel, g, t("Circle liquid glass", "لیکوید گلس دایره‌ها"), false) { body ->
            addNote(body, t("Same effect as the clock, applied to the circles (needs a wallpaper).", "همون افکت ساعت، روی دایره‌ها (نیاز به والپیپر داره)."))
            addGlassControls(body, s.gCircle)
        }

        for (i in 0..3) {
            addCapsule(panel, g, names[i], false) { body ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                val b1 = Button(this)
                b1.text = t("Choose logo from gallery", "انتخاب لوگو از گالری")
                b1.setOnClickListener { pick("image/*", REQ_LOGO + i) }
                val b2 = Button(this)
                b2.text = t("Remove logo", "حذف لوگو")
                b2.setOnClickListener {
                    s.logoFile(i).delete()
                    logos[i] = null
                    refresh()
                }
                row.addView(b1, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
                row.addView(b2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
                body.addView(row)
                addSlider(body, t("Logo size", "اندازه لوگو"), 0.2f, 0.95f, s.logoSize[i], { "%.2f".format(it) }) {
                    s.logoSize[i] = it
                    refresh()
                }
                addSwitch(body, t("Make the logo white", "سفید کردن لوگو"), s.logoWhite[i]) {
                    s.logoWhite[i] = it
                    refresh()
                }
                if (i == 0) {
                    addNote(body, t("The flashlight is built in: tapping it toggles the torch.", "چراغ قوه داخل خود اپ ساخته شده و با کلیک روشن و خاموش می‌شه."))
                } else {
                    addNote(
                        body,
                        t("Tapping this circle opens the app below. Empty = ", "با کلیک این دایره اپ زیر باز می‌شه. خالی بذاری: ") +
                            when (i) {
                                1 -> t("the default camera.", "دوربین پیش‌فرض.")
                                2 -> t("the dialer.", "شماره‌گیر.")
                                else -> t("does nothing.", "هیچ کاری نمی‌کنه.")
                            }
                    )
                    addField(body, t("Package name (e.g. com.whatsapp)", "نام پکیج (مثلا com.whatsapp)"), s.pkg[i]) { s.pkg[i] = it }
                    addField(body, t("Class name (optional, e.g. com.whatsapp.Main or .Main)", "نام کلس (اختیاری، مثلا com.whatsapp.Main یا .Main)"), s.cls[i]) { s.cls[i] = it }
                }
            }
        }
    }

    private fun addWallpaperControls(body: LinearLayout, m: Int) {
        addButton(body, t("Choose wallpaper from gallery", "انتخاب والپیپر از گالری")) {
            pendingWallMode = m
            pick("image/*", REQ_WALL)
        }
        addButton(body, t("Use the current lock screen wallpaper", "استفاده از والپیپر لاک‌اسکرین فعلی")) {
            importLockWallpaper(m, force = true, auto = false, onDone = null)
        }
        addSwitch(body, t("Auto-sync with the lock screen wallpaper when the app opens", "همگام‌سازی خودکار با والپیپر لاک‌اسکرین هنگام باز شدن اپ"), s.autoSync[m]) {
            s.autoSync[m] = it
            s.save()
        }
        addNote(
            body,
            t(
                "This needs the \"All files access\" permission. A video or live lock wallpaper can't be read; pick it from the gallery instead.",
                "این بخش به مجوز «دسترسی به همه فایل‌ها» (All files access) نیاز داره. والپیپر ویدیویی یا زنده خونده نمی‌شه و باید از گالری بذاری."
            )
        )
    }

    private fun addGlassControls(body: LinearLayout, g: GlassParams, withSwitch: Boolean = true) {
        if (withSwitch) {
            addSwitch(body, t("Liquid glass enabled", "لیکوید گلس فعال"), g.on) {
                g.on = it
                refresh()
            }
        }
        addSlider(body, t("Refraction height", "ارتفاع شکست نور"), 0f, 100f, g.refrH.toFloat(), { it.toInt().toString() }) {
            g.refrH = it.toInt()
            refresh()
        }
        addSlider(body, t("Refraction amount", "مقدار شکست نور"), 0f, 100f, g.refrA.toFloat(), { it.toInt().toString() }) {
            g.refrA = it.toInt()
            refresh()
        }
        addSwitch(body, t("Depth effect", "افکت عمق (depth)"), g.depth) {
            g.depth = it
            refresh()
        }
        addSwitch(body, t("Chromatic aberration (rainbow edges)", "رنگین‌کمانی لبه‌ها (chromatic aberration)"), g.chroma) {
            g.chroma = it
            refresh()
        }
        addSlider(body, t("Highlight strength", "شدت هایلایت"), 0f, 100f, g.hlStrength.toFloat(), { it.toInt().toString() }) {
            g.hlStrength = it.toInt()
            refresh()
        }
        addSlider(body, t("Highlight angle (degrees)", "زاویه هایلایت (درجه)"), 0f, 360f, g.hlAngle, { it.toInt().toString() }) {
            g.hlAngle = it
            refresh()
        }
        addSlider(body, t("Highlight falloff", "افت هایلایت (falloff)"), 0.5f, 4f, g.hlFalloff, { "%.2f".format(it) }) {
            g.hlFalloff = it
            refresh()
        }
        addSlider(body, t("Highlight width", "ضخامت هایلایت"), 0f, 100f, g.hlWidth.toFloat(), { it.toInt().toString() }) {
            g.hlWidth = it.toInt()
            refresh()
        }
        addSlider(body, t("Ambient highlight", "هایلایت محیطی (ambient)"), 0f, 100f, g.ambient.toFloat(), { it.toInt().toString() }) {
            g.ambient = it.toInt()
            refresh()
        }
        addSlider(body, t("Inner shadow", "سایه داخلی"), 0f, 100f, g.shadow.toFloat(), { it.toInt().toString() }) {
            g.shadow = it.toInt()
            refresh()
        }
    }

    // ------------------------------------------------------------------ mode

    private fun setMode(m: Int) {
        mode = m
        s.mode = m
        s.save()
        setModeUi()
        refresh()
    }

    private fun setModeUi() {
        clockPanel.visibility = if (mode == 0) View.VISIBLE else View.GONE
        shortPanel.visibility = if (mode == 1) View.VISIBLE else View.GONE
        for (i in 0..1) styleButton(modeButtons[i], i == mode)
    }

    private fun styleButton(b: Button, active: Boolean) {
        val bg = GradientDrawable()
        bg.cornerRadius = dp(18).toFloat()
        bg.setColor(if (active) 0xFF3D6DFF.toInt() else 0xFF2A2B31.toInt())
        b.background = bg
        b.setTextColor(Color.WHITE)
    }

    private fun formatLabel(f: Int) = when (f) {
        1 -> "h:mm"
        2 -> "HH:mm"
        else -> "hh:mm"
    }

    private fun updateFormatButton() {
        formatButton.text = formatLabel(s.timeFormat)
    }

    private fun showFormatMenu() {
        val m = PopupMenu(this, formatButton)
        m.menu.add(0, 0, 0, t("12-hour with zero (02:04)", "۱۲ ساعته با صفر (02:04)"))
        m.menu.add(0, 1, 1, t("12-hour without zero (2:04)", "۱۲ ساعته بدون صفر (2:04)"))
        m.menu.add(0, 2, 2, t("24-hour (14:04)", "۲۴ ساعته (14:04)"))
        m.setOnMenuItemClickListener {
            s.timeFormat = it.itemId
            s.save()
            updateFormatButton()
            if (mode == 0) refresh()
            true
        }
        m.show()
    }

    private fun addSegment(parent: LinearLayout, labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val btns = ArrayList<Button>()
        fun paint(sel: Int) {
            for (i in btns.indices) styleButton(btns[i], i == sel)
        }
        for (i in labels.indices) {
            val b = Button(this)
            b.text = labels[i]
            b.isAllCaps = false
            b.textSize = 13f
            b.minHeight = 0
            b.minimumHeight = 0
            b.setPadding(dp(6), dp(9), dp(6), dp(9))
            b.setOnClickListener {
                paint(i)
                onSelect(i)
            }
            btns.add(b)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.marginStart = dp(4)
            row.addView(b, lp)
        }
        paint(selected)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        parent.addView(row, lp)
    }

    private fun addColorSwatches(parent: LinearLayout) {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val line = LinearLayout(this)
        line.orientation = LinearLayout.HORIZONTAL
        hs.addView(line)
        val views = ArrayList<View>()
        fun paintAll() {
            for (i in views.indices) {
                val d = GradientDrawable()
                d.shape = GradientDrawable.OVAL
                d.setColor(Tint.colors[i])
                if (i == s.colorIdx) d.setStroke(dp(3), Color.WHITE) else d.setStroke(dp(1), 0x55FFFFFF)
                views[i].background = d
            }
        }
        for (i in Tint.colors.indices) {
            val v = View(this)
            v.setOnClickListener {
                s.colorIdx = i
                paintAll()
                updateShadeBar()
                refresh()
            }
            views.add(v)
            val lp = LinearLayout.LayoutParams(dp(38), dp(38))
            lp.marginEnd = dp(10)
            lp.topMargin = dp(4)
            lp.bottomMargin = dp(4)
            line.addView(v, lp)
        }
        colorSwatches = views
        paintAll()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        parent.addView(hs, lp)
    }

    /** Colors the shade slider: light -> chosen color -> dark, and tints its thumb with the current color. */
    private fun updateShadeBar() {
        val sb = shadeBar ?: return
        val base = Tint.colors[s.colorIdx.coerceIn(0, Tint.colors.size - 1)]
        val g = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Tint.shade(base, 0), base, Tint.shade(base, 100))
        )
        g.cornerRadius = dp(6).toFloat()
        g.setSize(1, dp(10))
        sb.progressDrawable = g
        sb.thumbTintList = ColorStateList.valueOf(s.tintColor())
    }

    // ------------------------------------------------------------------ UI helpers

    private fun addCapsule(parent: LinearLayout, group: MutableList<Cap>, title: String, open: Boolean, build: (LinearLayout) -> Unit) {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable()
        bg.cornerRadius = dp(22).toFloat()
        bg.setColor(0xFF1D1E23.toInt())
        card.background = bg
        card.setPadding(dp(16), dp(14), dp(16), dp(14))

        val header = TextView(this)
        header.textSize = 17f
        header.setTextColor(0xFF8FD3FF.toInt())
        header.text = (if (open) "▾  " else "▸  ") + title
        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.visibility = if (open) View.VISIBLE else View.GONE
        val cap = Cap(header, body, title)
        group.add(cap)
        header.setOnClickListener {
            val willOpen = body.visibility != View.VISIBLE
            for (c in group) {
                c.body.visibility = View.GONE
                c.header.text = "▸  " + c.title
            }
            if (willOpen) {
                body.visibility = View.VISIBLE
                header.text = "▾  $title"
            }
        }
        card.addView(header)
        card.addView(body)
        build(body)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        parent.addView(card, lp)
    }

    private fun addNote(parent: LinearLayout, text: String) {
        val tv = TextView(this)
        tv.text = text
        tv.setTextColor(0xFF999999.toInt())
        tv.textSize = 13f
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        parent.addView(tv, lp)
    }

    private fun addField(parent: LinearLayout, hint: String, init: String, onChange: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(0xFF777777.toInt())
        et.setTextColor(Color.WHITE)
        et.setText(init)
        et.isSingleLine = true
        et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        et.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(e: Editable?) {
                onChange(e?.toString() ?: "")
            }

            override fun beforeTextChanged(c: CharSequence?, st: Int, cnt: Int, aft: Int) {}
            override fun onTextChanged(c: CharSequence?, st: Int, b: Int, cnt: Int) {}
        })
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(4)
        parent.addView(et, lp)
    }

    private fun addSwitch(parent: LinearLayout, text: String, init: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = text
        sw.setTextColor(Color.WHITE)
        sw.isChecked = init
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(10)
        parent.addView(sw, lp)
    }

    private fun addButton(parent: LinearLayout, text: String, onClick: () -> Unit) {
        val b = Button(this)
        b.text = text
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(6)
        parent.addView(b, lp)
    }

    private fun addSlider(
        parent: LinearLayout,
        title: String,
        min: Float,
        max: Float,
        init: Float,
        fmt: (Float) -> String,
        bar: ((SeekBar) -> Unit)? = null,
        onChange: (Float) -> Unit
    ) {
        val label = TextView(this)
        label.setTextColor(Color.WHITE)
        label.text = "$title: ${fmt(init)}"
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(12)
        parent.addView(label, lp)

        val sb = SeekBar(this)
        sb.max = 1000
        sb.progress = (((init - min) / (max - min)) * 1000f).toInt().coerceIn(0, 1000)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = min + (max - min) * progress / 1000f
                label.text = "$title: ${fmt(v)}"
                if (fromUser) {
                    overlayLabel.text = label.text
                    onChange(v)
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                overlayLabel.text = label.text
                overlayLayer.visibility = View.VISIBLE
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                overlayLayer.visibility = View.GONE
            }
        })
        parent.addView(sb)
        bar?.invoke(sb)
    }

    // ------------------------------------------------------------------ wallpapers

    private fun pick(type: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = type
        @Suppress("DEPRECATION")
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) return
        if (requestCode == REQ_WALL) {
            importWall(uri, pendingWallMode)
        } else if (requestCode == REQ_CLOCK_FONT) {
            if (Fonts.import(this, uri, "clock_font.ttf")) refresh() else toast(t("Could not read the font", "خطا در خواندن فونت"))
        } else if (requestCode == REQ_DATE_FONT) {
            if (Fonts.import(this, uri, "date_font.ttf")) refresh() else toast(t("Could not read the font", "خطا در خواندن فونت"))
        } else if (requestCode in REQ_LOGO..(REQ_LOGO + 3)) {
            importLogo(uri, requestCode - REQ_LOGO)
        }
    }

    private fun importLogo(uri: Uri, idx: Int) {
        try {
            val src = ImageDecoder.createSource(contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val m = maxOf(info.size.width, info.size.height)
                if (m > 512) {
                    val sc = 512f / m
                    dec.setTargetSize(
                        (info.size.width * sc).toInt().coerceAtLeast(1),
                        (info.size.height * sc).toInt().coerceAtLeast(1)
                    )
                }
            }
            s.logoFile(idx).outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            logos[idx] = bmp
            refresh()
        } catch (e: Exception) {
            toast(t("Could not read the logo", "خطا در خواندن لوگو"))
        }
    }

    /** Decodes an image, scales/crops it to the screen size and stores it as the working wallpaper of mode m. */
    private fun processWall(src: ImageDecoder.Source, m: Int): Bitmap {
        val (sw, sh) = realScreenSize(this)
        val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val sc = maxOf(sw.toFloat() / info.size.width, sh.toFloat() / info.size.height)
            if (sc < 1f) {
                val tw = ceil(info.size.width * sc).toInt().coerceAtLeast(sw)
                val th = ceil(info.size.height * sc).toInt().coerceAtLeast(sh)
                dec.setTargetSize(tw, th)
            }
        }
        val sc2 = maxOf(sw.toFloat() / bmp.width, sh.toFloat() / bmp.height)
        val scW = ceil(bmp.width * sc2).toInt().coerceAtLeast(sw)
        val scH = ceil(bmp.height * sc2).toInt().coerceAtLeast(sh)
        val scaled = if (scW != bmp.width || scH != bmp.height) Bitmap.createScaledBitmap(bmp, scW, scH, true) else bmp
        val out = Bitmap.createBitmap(scaled, (scW - sw) / 2, (scH - sh) / 2, sw, sh)
        s.wallFile(m).outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        s.wallW = sw
        s.wallH = sh
        return out
    }

    private fun importWall(uri: Uri, m: Int) {
        toast(t("Preparing wallpaper...", "در حال آماده‌سازی والپیپر..."))
        Thread {
            try {
                val out = processWall(ImageDecoder.createSource(contentResolver, uri), m)
                runOnUiThread {
                    walls[m] = out
                    if (m == mode) refresh()
                }
            } catch (e: Exception) {
                runOnUiThread { toast(t("Could not read the image", "خطا در خواندن عکس")) }
            }
        }.start()
    }

    /**
     * Reads the current lock screen wallpaper (falls back to the home wallpaper if there is no separate
     * lock one) into mode m. Needs "All files access" on Android 13+. With auto = true it stays silent,
     * only runs when the wallpaper changed since the last import, and then applies to the widgets.
     */
    private fun importLockWallpaper(m: Int, force: Boolean, auto: Boolean, onDone: (() -> Unit)?) {
        if (importing) {
            onDone?.invoke()
            return
        }
        val wm = WallpaperManager.getInstance(this)
        val lockId = try {
            wm.getWallpaperId(WallpaperManager.FLAG_LOCK)
        } catch (e: Exception) {
            -1
        }
        val id = if (lockId >= 0) lockId else try {
            wm.getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (e: Exception) {
            -1
        }
        if (!force && id >= 0 && id == s.lockWallId[m]) {
            onDone?.invoke()
            return
        }
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            if (!auto) {
                pendingLockImportMode = m
                toast(t("Turn on \"All files access\" for the app, then come back", "«All files access» رو برای اپ روشن کن و برگرد"))
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
            onDone?.invoke()
            return
        }

        importing = true
        if (!auto) toast(t("Reading the lock screen wallpaper...", "در حال خواندن والپیپر لاک‌اسکرین..."))
        Thread {
            try {
                val pfd = wm.getWallpaperFile(WallpaperManager.FLAG_LOCK)
                    ?: wm.getWallpaperFile(WallpaperManager.FLAG_SYSTEM)
                    ?: throw IllegalStateException("no wallpaper file")
                val tmp = File(cacheDir, "lock_src")
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { input ->
                    tmp.outputStream().use { input.copyTo(it) }
                }
                val out = processWall(ImageDecoder.createSource(tmp), m)
                s.lockWallId[m] = id
                runOnUiThread {
                    importing = false
                    walls[m] = out
                    if (m == mode) refresh()
                    s.save()
                    if (auto) {
                        applyMode(m, true)
                    } else {
                        toast(t("Lock screen wallpaper loaded. Adjust, then tap \"Save and apply\".", "والپیپر لاک‌اسکرین بارگذاری شد. بعد از تنظیم، «ثبت و اعمال» رو بزن."))
                    }
                    onDone?.invoke()
                }
            } catch (e: SecurityException) {
                runOnUiThread {
                    importing = false
                    if (!auto) toast(t("Can't access the wallpaper; \"All files access\" is needed", "دسترسی به والپیپر ممکن نیست؛ «All files access» لازمه"))
                    onDone?.invoke()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    importing = false
                    if (!auto) toast(t("Couldn't read the lock wallpaper (maybe video or live). Pick it from the gallery.", "خوندن والپیپر لاک‌اسکرین ممکن نشد (شاید ویدیویی یا زنده‌ست). از گالری انتخاب کن."))
                    onDone?.invoke()
                }
            }
        }.start()
    }

    private fun loadWalls() {
        for (m in 0..1) {
            walls[m] = try {
                if (s.wallFile(m).exists()) BitmapFactory.decodeFile(s.wallFile(m).absolutePath) else null
            } catch (e: Exception) {
                null
            }
            walls[m]?.let {
                s.wallW = it.width
                s.wallH = it.height
            }
        }
    }

    /** Takes the clock widget size from the placed widget so the image is drawn 1:1 (sharp). */
    private fun syncHostSize() {
        if (!s.followSize) return
        val hs = WidgetUpdater.hostSize(this, ClockWidgetProvider::class.java) ?: return
        val nw = (hs.first.toFloat() / s.wallW).coerceIn(0.2f, 1f)
        val nh = (hs.second.toFloat() / s.wallH).coerceIn(0.05f, 0.9f)
        if (abs(nw - s.widthFrac) > 0.002f || abs(nh - s.heightFrac) > 0.002f) {
            s.widthFrac = nw
            s.heightFrac = nh
            s.save()
            refresh()
        }
    }

    // ------------------------------------------------------------------ rendering

    private fun showPreviews(w: Bitmap?, c: Bitmap?) {
        preview.set(w, c, circleBmps, s, mode)
        overlayPreview.set(w, c, circleBmps, s, mode)
    }

    private fun refresh(fast: Boolean = false) {
        s.clampPos()
        gen++
        if (mode == 0) refreshClock(fast) else refreshCircles(fast)
    }

    private fun refreshCircles(fast: Boolean) {
        val w = walls[1]
        for (i in 0..3) {
            val f = if (w != null) {
                Blur.buildRegion(w, s, s.cx[i], s.cy[i], s.circleSize, s.circleHFrac(), s.circleBlur, s.circleWhite, s.circleDark)
            } else null
            circleBmps[i] = CircleRenderer.render(s, i, f, logos[i], !fast)
        }
        showPreviews(w, null)
    }

    private fun refreshClock(fast: Boolean) {
        val w = walls[0]
        lastFill = if ((s.blurOn || s.colorOn || s.realGlassActive()) && w != null) Blur.buildClockFill(w, s) else null
        lastDateFill = if (s.dateBlurOn && w != null) Blur.buildFill(w, s, s.dateBlur, s.dateWhite) else null
        if (s.gClock.on && !fast && lastFill != null) {
            renderGlassAsync(w)
        } else {
            clockBmp = ClockRenderer.render(this, s, lastFill, lastDateFill, false)
            showPreviews(w, clockBmp)
        }
    }

    private fun renderGlassAsync(w: Bitmap?) {
        if (busy) {
            dirty = true
            return
        }
        busy = true
        dirty = false
        val myGen = gen
        val cf = lastFill
        val df = lastDateFill
        Thread {
            val bmp: Bitmap? = try {
                ClockRenderer.render(this, s, cf, df, true)
            } catch (e: Throwable) {
                null
            }
            runOnUiThread {
                busy = false
                if (bmp != null && myGen == gen && mode == 0) {
                    clockBmp = bmp
                    showPreviews(w, bmp)
                }
                if (dirty) refresh()
            }
        }.start()
    }

    /** Saves the settings, rebuilds the blurred fills of mode m and updates its widgets. */
    private fun applyMode(m: Int, silent: Boolean) {
        s.save()
        val w = walls[m]
        if (m == 0) {
            val f = if ((s.blurOn || s.colorOn || s.realGlassActive()) && w != null) Blur.buildClockFill(w, s) else null
            if (f != null) s.fillFile().outputStream().use { f.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val df = if (s.dateBlurOn && w != null) Blur.buildFill(w, s, s.dateBlur, s.dateWhite) else null
            if (df != null) s.dateFillFile().outputStream().use { df.compress(Bitmap.CompressFormat.PNG, 100, it) }
            WidgetUpdater.updateClock(this)
        } else {
            for (i in 0..3) {
                val f = if (w != null) {
                    Blur.buildRegion(w, s, s.cx[i], s.cy[i], s.circleSize, s.circleHFrac(), s.circleBlur, s.circleWhite, s.circleDark)
                } else null
                if (f != null) s.circleFillFile(i).outputStream().use { f.compress(Bitmap.CompressFormat.PNG, 100, it) }
            }
            WidgetUpdater.updateCircles(this)
        }
        if (!silent) toast(t("Applied", "اعمال شد"))
    }
}
