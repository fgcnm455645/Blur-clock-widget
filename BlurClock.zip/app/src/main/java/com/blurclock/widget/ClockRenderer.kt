package com.blurclock.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.Shader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object ClockRenderer {

    fun widgetWidth(s: ClockSettings) = (s.widthFrac * s.wallW).roundToInt().coerceAtLeast(2)
    fun widgetHeight(s: ClockSettings) = (s.heightFrac * s.wallH).roundToInt().coerceAtLeast(2)

    /**
     * Draws the transparent widget image: date on top, clock below.
     * A fill bitmap makes the text show the blurred wallpaper; null means plain white.
     * Liquid glass is applied to the clock when [glass] is true and the clock has a fill.
     * outW/outH = real widget size in px: drawing at exactly that size means the launcher never has
     * to scale the image, which keeps thin edges and highlights sharp.
     */
    fun render(
        ctx: Context,
        s: ClockSettings,
        clockFill: Bitmap?,
        dateFill: Bitmap?,
        glass: Boolean = s.gClock.on,
        outW: Int = 0,
        outH: Int = 0
    ): Bitmap {
        val w = if (outW > 0) outW else widgetWidth(s)
        val h = if (outH > 0) outH else widgetHeight(s)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val now = Date()

        val tint = s.colorOn
        val dateTint = tint && s.colorDate
        val dateP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (dateTint) s.tintColor() else Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = s.dateSize * s.wallW
            typeface = Fonts.date(ctx)
        }
        val dateText = SimpleDateFormat("EEE, MMMM d", Locale.ENGLISH).format(now)
        val dm = dateP.fontMetrics
        val dateBaseline = -dm.ascent
        val dateBottom = dateBaseline + dm.descent

        val clockP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (tint && clockFill == null) s.tintColor() else Color.WHITE
            textAlign = Paint.Align.CENTER
            textSize = s.clockSize * s.wallW
            textScaleX = s.clockScaleX
            typeface = Fonts.clock(ctx)
        }
        val pattern = when (s.timeFormat) {
            1 -> "h:mm"    // 12h without leading zero
            2 -> "HH:mm"   // 24h
            else -> "hh:mm" // 12h with leading zero
        }
        val clockText = SimpleDateFormat(pattern, Locale.ENGLISH).format(now)
        val ref = Rect()
        clockP.getTextBounds("0123456789", 0, 10, ref)
        val baseline = dateBottom + s.gap * s.wallH - ref.top

        drawLayer(c, dateText, w / 2f, dateBaseline, dateP, if (dateTint) null else dateFill, w, h, false, s)

        if (s.fadeOn) {
            // bottom fade (KWGT style): the clock layer is multiplied by a vertical alpha gradient.
            // width = size of the fade zone, offset = its center, both in % of the digit height.
            val layer = c.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
            drawLayer(c, clockText, w / 2f, baseline, clockP, clockFill, w, h, glass, s)
            val top = baseline + ref.top
            val hh = maxOf(1f, (baseline + ref.bottom) - top)
            val center = s.fadeOffset.coerceIn(0, 100) / 100f
            val half = s.fadeWidth.coerceIn(1, 100) / 200f
            val y0 = top + hh * (center - half)
            var y1 = top + hh * (center + half)
            if (y1 - y0 < 1f) y1 = y0 + 1f
            val fp = Paint().apply {
                shader = LinearGradient(0f, y0, 0f, y1, 0xFFFFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP)
                xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
            }
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), fp)
            c.restoreToCount(layer)
        } else {
            drawLayer(c, clockText, w / 2f, baseline, clockP, clockFill, w, h, glass, s)
        }
        return bmp
    }

    private fun drawLayer(
        c: Canvas, text: String, x: Float, y: Float, paint: Paint,
        fill: Bitmap?, w: Int, h: Int, glass: Boolean, s: ClockSettings
    ) {
        if (fill == null) {
            c.drawText(text, x, y, paint)
            return
        }
        val mask = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(mask).drawText(text, x, y, paint)

        if (glass) {
            val n = w * h
            val ap = IntArray(n)
            mask.getPixels(ap, 0, w, 0, 0, w, h)
            for (i in 0 until n) ap[i] = ap[i] ushr 24
            val fs = if (fill.width == w && fill.height == h) fill else Bitmap.createScaledBitmap(fill, w, h, true)
            val fp = IntArray(n)
            fs.getPixels(fp, 0, w, 0, 0, w, h)
            val res = if (s.glassType == 1) {
                LiquidGlassOld.apply(ap, fp, w, h, paint.textSize, s.oldRefr, s.oldGloss)
            } else if (s.glassType == 2) {
                LiquidGlassReal.apply(ap, fp, w, h, s)
            } else {
                LiquidGlass.apply(ap, fp, w, h, s.gClock.toParams(paint.textSize))
            }
            val lb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            lb.setPixels(res, 0, w, 0, 0, w, h)
            c.drawBitmap(lb, 0f, 0f, null)
            lb.recycle()
        } else {
            val layer = c.saveLayer(0f, 0f, w.toFloat(), h.toFloat(), null)
            c.drawBitmap(fill, null, Rect(0, 0, w, h), null)
            val maskPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
            c.drawBitmap(mask, 0f, 0f, maskPaint)
            c.restoreToCount(layer)
        }
        mask.recycle()
    }
}
