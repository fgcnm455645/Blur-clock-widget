package com.blurclock.widget

import kotlin.math.max
import kotlin.math.min

/**
 * Liquid glass look for a text mask: edge refraction (background is shifted near the
 * edges), a bright specular highlight on the top-left edges, a light rim and a soft
 * shade on the bottom-right edges.
 */
object LiquidGlassOld {

    /**
     * alpha: text mask alpha (0..255), fill: ARGB pixels of the blurred wallpaper (same size).
     * Returns ARGB pixels (non-premultiplied) of the glass text.
     */
    fun apply(alpha: IntArray, fill: IntArray, w: Int, h: Int, textSize: Float, refraction: Int, gloss: Int): IntArray {
        val r = (textSize * 0.012f).toInt().coerceIn(2, 10)
        val hf = alpha.copyOf()
        repeat(2) {
            blur1(hf, w, h, r, true)
            blur1(hf, w, h, r, false)
        }
        val shiftMax = textSize * 0.04f * refraction / 100f
        val g = gloss / 100f
        val rf = r.toFloat()
        val out = IntArray(w * h)

        for (y in 1 until h - 1) {
            val row = y * w
            for (x in 1 until w - 1) {
                val i = row + x
                val a = alpha[i]
                if (a == 0) continue

                val gx = ((hf[i + 1] - hf[i - 1]) / 510f * rf).coerceIn(-1.5f, 1.5f)
                val gy = ((hf[i + w] - hf[i - w]) / 510f * rf).coerceIn(-1.5f, 1.5f)

                // refraction: sample the fill a little towards the inside of the glyph
                val sx = (x + gx * shiftMax).toInt().coerceIn(0, w - 1)
                val sy = (y + gy * shiftMax).toInt().coerceIn(0, h - 1)
                val c = fill[sy * w + sx]
                var cr = ((c shr 16) and 255).toFloat()
                var cg = ((c shr 8) and 255).toFloat()
                var cb = (c and 255).toFloat()

                // light comes from the top-left
                val spec = 0.7071f * (gx + gy)
                val hl = (spec * 1.4f).coerceIn(0f, 1f).let { it * it }
                val shade = max(0f, -spec).coerceAtMost(1f)

                val dark = shade * 0.35f * g
                cr *= (1f - dark)
                cg *= (1f - dark)
                cb *= (1f - dark)

                val hv = hf[i] / 255f
                val rim = ((0.72f - hv) / 0.25f).coerceIn(0f, 1f) * 0.45f * g
                val white = min(1f, hl * 0.9f * g + rim)
                cr += (255f - cr) * white
                cg += (255f - cg) * white
                cb += (255f - cb) * white

                out[i] = (a shl 24) or
                    (cr.toInt().coerceIn(0, 255) shl 16) or
                    (cg.toInt().coerceIn(0, 255) shl 8) or
                    cb.toInt().coerceIn(0, 255)
            }
        }
        return out
    }

    private fun blur1(px: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        val tmp = IntArray(len)
        for (line in 0 until lines) {
            val start = if (horizontal) line * w else line
            var sum = 0
            for (i in -r..r) sum += px[start + i.coerceIn(0, len - 1) * step]
            for (x in 0 until len) {
                tmp[x] = sum / div
                sum += px[start + min(x + r + 1, len - 1) * step] - px[start + max(x - r, 0) * step]
            }
            for (x in 0 until len) px[start + x * step] = tmp[x]
        }
    }
}
