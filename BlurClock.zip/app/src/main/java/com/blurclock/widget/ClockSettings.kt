package com.blurclock.widget

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File

@Suppress("DEPRECATION")
fun realScreenSize(ctx: Context): Pair<Int, Int> {
    val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val dm = DisplayMetrics()
    wm.defaultDisplay.getRealMetrics(dm)
    return Pair(minOf(dm.widthPixels, dm.heightPixels), maxOf(dm.widthPixels, dm.heightPixels))
}

/** Liquid glass settings (one set for the clock, one for the shortcut circles). */
class GlassParams {
    var on = true
    var refrH = 55           // 0..100 refraction height
    var refrA = 55           // 0..100 refraction amount
    var depth = false
    var chroma = true
    var hlStrength = 50      // 0..100
    var hlAngle = 45f        // degrees
    var hlFalloff = 1f
    var hlWidth = 30         // 0..100
    var ambient = 25         // 0..100
    var shadow = 25          // 0..100

    fun load(p: SharedPreferences, pre: String) {
        on = p.getBoolean(pre + "on", on)
        refrH = p.getInt(pre + "refrH", refrH)
        refrA = p.getInt(pre + "refrA", refrA)
        depth = p.getBoolean(pre + "depth", depth)
        chroma = p.getBoolean(pre + "chroma", chroma)
        hlStrength = p.getInt(pre + "hlStrength", hlStrength)
        hlAngle = p.getFloat(pre + "hlAngle", hlAngle)
        hlFalloff = p.getFloat(pre + "hlFalloff", hlFalloff)
        hlWidth = p.getInt(pre + "hlWidth", hlWidth)
        ambient = p.getInt(pre + "ambient", ambient)
        shadow = p.getInt(pre + "shadow", shadow)
    }

    fun save(e: SharedPreferences.Editor, pre: String) {
        e.putBoolean(pre + "on", on).putInt(pre + "refrH", refrH).putInt(pre + "refrA", refrA)
            .putBoolean(pre + "depth", depth).putBoolean(pre + "chroma", chroma)
            .putInt(pre + "hlStrength", hlStrength).putFloat(pre + "hlAngle", hlAngle)
            .putFloat(pre + "hlFalloff", hlFalloff).putInt(pre + "hlWidth", hlWidth)
            .putInt(pre + "ambient", ambient).putInt(pre + "shadow", shadow)
    }

    /** "Real" glass: every size is scaled from d = half of the thickest digit stroke (px). */
    fun toRealParams(d: Float) = LiquidGlass.Params(
        refrHeight = refrH / 100f * d,
        refrAmount = refrA / 100f * 2f * d,
        depth = depth,
        chroma = chroma,
        hlStrength = hlStrength / 100f,
        hlAngleDeg = hlAngle,
        hlFalloff = hlFalloff,
        hlWidth = maxOf(1.5f, hlWidth / 100f * 0.12f * d),
        ambient = ambient / 100f,
        shadow = shadow / 100f * 0.6f,
        shadowRadius = 0.3f * d,
        shadowOffset = 0.15f * d
    )

    /** ts = reference size in px (text size for the clock, about 2.5 x diameter for a circle). */
    fun toParams(ts: Float) = LiquidGlass.Params(
        refrHeight = refrH / 100f * 0.05f * ts,
        refrAmount = refrA / 100f * 0.07f * ts,
        depth = depth,
        chroma = chroma,
        hlStrength = hlStrength / 100f,
        hlAngleDeg = hlAngle,
        hlFalloff = hlFalloff,
        hlWidth = hlWidth / 100f * 0.03f * ts,
        ambient = ambient / 100f,
        shadow = shadow / 100f * 0.6f,
        shadowRadius = 0.015f * ts,
        shadowOffset = 0.012f * ts
    )
}

/** Pastel tint colors for the "Color blur" option, plus the light-to-dark shade math. */
object Tint {
    val colors = intArrayOf(
        0xFFA8E8FF.toInt(), 0xFFB3CCFF.toInt(), 0xFFD9C8FF.toInt(), 0xFFDD99FF.toInt(),
        0xFFF5A9C4.toInt(), 0xFFFFC9BD.toInt(), 0xFFFFD9AE.toInt(), 0xFFFFE5B0.toInt(),
        0xFFFFFACD.toInt(), 0xFFEEF5BD.toInt(), 0xFFC8E6B5.toInt(), 0xFFB5F0D5.toInt(),
        0xFFFFFFFF.toInt()
    )

    private fun mix(a: Int, b: Int, k: Float): Int {
        val r = (((a shr 16) and 255) * (1f - k) + ((b shr 16) and 255) * k).toInt().coerceIn(0, 255)
        val g = (((a shr 8) and 255) * (1f - k) + ((b shr 8) and 255) * k).toInt().coerceIn(0, 255)
        val bl = ((a and 255) * (1f - k) + (b and 255) * k).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** shade 0..100: 0 = almost white, 50 = the swatch color, 100 = almost black. */
    fun shade(base: Int, shade: Int): Int {
        // white swatch: the slider runs from white to full black
        if (base == 0xFFFFFFFF.toInt()) return mix(base, 0xFF000000.toInt(), shade / 100f)
        return if (shade < 50) mix(base, 0xFFFFFFFF.toInt(), (50 - shade) / 50f * 0.9f)
        else mix(base, 0xFF000000.toInt(), (shade - 50) / 50f * 0.9f)
    }
}

class ClockSettings(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("clock", Context.MODE_PRIVATE)

    var lang = "en"          // "en" or "fa"
    var mode = 0             // 0 clock, 1 shortcuts

    var wallW = 0
    var wallH = 0
    val autoSync = booleanArrayOf(false, false)   // per mode: follow the lock screen wallpaper
    val lockWallId = intArrayOf(-2, -2)

    // ---- clock ----
    var posX = 0.025f        // widget left, fraction of screen width
    var posY = 0.12f         // widget top, fraction of screen height
    var widthFrac = 0.95f    // widget width, fraction of screen width
    var heightFrac = 0.38f   // widget height, fraction of screen height
    var followSize = true    // take the widget size from the placed widget
    var clockSize = 0.95f    // clock text size, fraction of screen width
    var clockScaleX = 1f     // horizontal stretch of clock digits
    var dateSize = 0.055f    // date text size, fraction of screen width
    var gap = 0.01f          // gap between date and clock, fraction of screen height
    var blurOn = true
    var blur = 60            // 0..100
    var white = 55           // 0..100
    var dateBlurOn = true
    var dateBlur = 40        // 0..100
    var dateWhite = 55       // 0..100
    val gClock = GlassParams()
    var glassType = 0        // 0 new liquid glass (Backdrop), 1 old liquid glass, 2 real (thick lens) liquid glass
    val gReal = GlassParams().apply {
        refrH = 50
        refrA = 50
        depth = false
        chroma = true
        hlStrength = 60
        hlWidth = 30
        ambient = 25
        shadow = 30
    }
    var realBlur = 10        // 0..100 blur of the backdrop inside the glass (real glass only)
    var realTint = 15        // 0..100 white surface tint (real glass only)
    var realVibrancy = 50    // 0..100 saturation boost, 50 = x1.5 (real glass only)
    var oldRefr = 60         // 0..100 (old glass)
    var oldGloss = 60        // 0..100 (old glass)
    var timeFormat = 0       // 0 = 12h with leading zero (02:04), 1 = 12h without (2:04), 2 = 24h (14:04)

    // color blur (tinted clock)
    var colorOn = false
    var colorIdx = 3
    var colorShade = 50      // 0..100
    var colorStrength = 70   // 0..100 (glass mode: how much of the tint replaces the wallpaper)
    var colorSolid = false   // false = glass (wallpaper shows through), true = flat color with a soft gradient
    var colorDate = true     // tint the date with the same color

    // bottom fade (like the KWGT gradient FX)
    var fadeOn = false
    var fadeWidth = 50       // 1..100, size of the fade zone (percent of digit height)
    var fadeOffset = 50      // 0..100, center of the fade zone (percent of digit height from the top)

    // ---- shortcut circles: 0 flashlight, 1 camera, 2 phone, 3 custom ----
    val cx = floatArrayOf(0.05f, 0.808f, 0.05f, 0.43f)
    val cy = floatArrayOf(0.897f, 0.897f, 0.78f, 0.78f)
    var circleSize = 0.14f   // diameter, fraction of screen width
    var circleBlur = 60      // 0..100
    var circleWhite = 25     // 0..100
    var circleDark = 35      // 0..100
    var frameOn = false
    var frameThick = 0.03f   // fraction of the circle diameter
    var frameAlpha = 80      // 0..100
    val logoSize = floatArrayOf(0.5f, 0.5f, 0.5f, 0.5f)   // fraction of the circle diameter
    val logoWhite = booleanArrayOf(false, false, false, false)
    val pkg = arrayOf("", "", "", "")
    val cls = arrayOf("", "", "", "")
    val gCircle = GlassParams()

    init {
        load()
    }

    /** The real glass needs a light blur, so its backdrop is built with its own blur / tint values. */
    fun realGlassActive() = gClock.on && glassType == 2

    fun tintColor(): Int = Tint.shade(Tint.colors[colorIdx.coerceIn(0, Tint.colors.size - 1)], colorShade)

    fun circleHFrac(): Float = circleSize * wallW / wallH

    fun load() {
        val (sw, sh) = realScreenSize(ctx)
        lang = p.getString("lang", "en") ?: "en"
        mode = p.getInt("mode", 0)
        wallW = p.getInt("wallW", sw)
        wallH = p.getInt("wallH", sh)
        autoSync[0] = p.getBoolean("autoSync", false)
        autoSync[1] = p.getBoolean("autoSync_c", false)
        lockWallId[0] = p.getInt("lockWallId", -2)
        lockWallId[1] = p.getInt("lockWallId_c", -2)

        posX = p.getFloat("posX", posX)
        posY = p.getFloat("posY", posY)
        widthFrac = p.getFloat("widthFrac", widthFrac)
        heightFrac = p.getFloat("heightFrac", heightFrac)
        followSize = p.getBoolean("followSize", followSize)
        clockSize = p.getFloat("clockSize", clockSize)
        clockScaleX = p.getFloat("clockScaleX", clockScaleX)
        dateSize = p.getFloat("dateSize", dateSize)
        gap = p.getFloat("gap", gap)
        blurOn = p.getBoolean("blurOn", blurOn)
        blur = p.getInt("blur", blur)
        white = p.getInt("white", white)
        dateBlurOn = p.getBoolean("dateBlurOn", dateBlurOn)
        dateBlur = p.getInt("dateBlur", dateBlur)
        dateWhite = p.getInt("dateWhite", dateWhite)
        gClock.load(p, "gc_")
        glassType = p.getInt("glassType", glassType)
        gReal.load(p, "gr_")
        realBlur = p.getInt("realBlur", realBlur)
        realTint = p.getInt("realTint", realTint)
        realVibrancy = p.getInt("realVibrancy", realVibrancy)
        oldRefr = p.getInt("oldRefr", oldRefr)
        oldGloss = p.getInt("oldGloss", oldGloss)
        timeFormat = p.getInt("timeFormat", timeFormat)
        colorOn = p.getBoolean("colorOn", colorOn)
        colorIdx = p.getInt("colorIdx", colorIdx)
        colorShade = p.getInt("colorShade", colorShade)
        colorStrength = p.getInt("colorStrength", colorStrength)
        colorSolid = p.getBoolean("colorSolid", colorSolid)
        colorDate = p.getBoolean("colorDate", colorDate)
        fadeOn = p.getBoolean("fadeOn", fadeOn)
        fadeWidth = p.getInt("fadeWidth", fadeWidth)
        fadeOffset = p.getInt("fadeOffset", fadeOffset)

        circleSize = p.getFloat("circleSize", circleSize)
        circleBlur = p.getInt("circleBlur", circleBlur)
        circleWhite = p.getInt("circleWhite", circleWhite)
        circleDark = p.getInt("circleDark", circleDark)
        frameOn = p.getBoolean("frameOn", frameOn)
        frameThick = p.getFloat("frameThick", frameThick)
        frameAlpha = p.getInt("frameAlpha", frameAlpha)
        for (i in 0..3) {
            cx[i] = p.getFloat("cx$i", cx[i])
            cy[i] = p.getFloat("cy$i", cy[i])
            logoSize[i] = p.getFloat("logoSize$i", logoSize[i])
            logoWhite[i] = p.getBoolean("logoWhite$i", logoWhite[i])
            pkg[i] = p.getString("pkg$i", "") ?: ""
            cls[i] = p.getString("cls$i", "") ?: ""
        }
        gCircle.load(p, "gs_")
    }

    fun save() {
        val e = p.edit()
        e.putString("lang", lang).putInt("mode", mode)
            .putInt("wallW", wallW).putInt("wallH", wallH)
            .putBoolean("autoSync", autoSync[0]).putBoolean("autoSync_c", autoSync[1])
            .putInt("lockWallId", lockWallId[0]).putInt("lockWallId_c", lockWallId[1])
            .putFloat("posX", posX).putFloat("posY", posY)
            .putFloat("widthFrac", widthFrac).putFloat("heightFrac", heightFrac)
            .putBoolean("followSize", followSize)
            .putFloat("clockSize", clockSize).putFloat("clockScaleX", clockScaleX)
            .putFloat("dateSize", dateSize).putFloat("gap", gap)
            .putBoolean("blurOn", blurOn).putInt("blur", blur).putInt("white", white)
            .putBoolean("dateBlurOn", dateBlurOn).putInt("dateBlur", dateBlur).putInt("dateWhite", dateWhite)
            .putFloat("circleSize", circleSize).putInt("circleBlur", circleBlur)
            .putInt("circleWhite", circleWhite).putInt("circleDark", circleDark)
            .putBoolean("frameOn", frameOn).putFloat("frameThick", frameThick).putInt("frameAlpha", frameAlpha)
        gClock.save(e, "gc_")
        gReal.save(e, "gr_")
        e.putInt("realBlur", realBlur).putInt("realTint", realTint).putInt("realVibrancy", realVibrancy)
        e.putInt("glassType", glassType).putInt("oldRefr", oldRefr).putInt("oldGloss", oldGloss)
            .putInt("timeFormat", timeFormat)
            .putBoolean("colorOn", colorOn).putInt("colorIdx", colorIdx).putInt("colorShade", colorShade)
            .putInt("colorStrength", colorStrength).putBoolean("colorSolid", colorSolid).putBoolean("colorDate", colorDate)
            .putBoolean("fadeOn", fadeOn).putInt("fadeWidth", fadeWidth).putInt("fadeOffset", fadeOffset)
        gCircle.save(e, "gs_")
        for (i in 0..3) {
            e.putFloat("cx$i", cx[i]).putFloat("cy$i", cy[i])
                .putFloat("logoSize$i", logoSize[i]).putBoolean("logoWhite$i", logoWhite[i])
                .putString("pkg$i", pkg[i]).putString("cls$i", cls[i])
        }
        e.apply()
    }

    fun clampPos() {
        posX = posX.coerceIn(0f, maxOf(0f, 1f - widthFrac))
        posY = posY.coerceIn(0f, maxOf(0f, 1f - heightFrac))
        for (i in 0..3) {
            cx[i] = cx[i].coerceIn(0f, maxOf(0f, 1f - circleSize))
            cy[i] = cy[i].coerceIn(0f, maxOf(0f, 1f - circleHFrac()))
        }
    }

    fun wallFile(m: Int) = File(ctx.filesDir, if (m == 0) "wall.jpg" else "wall_c.jpg")
    fun fillFile() = File(ctx.filesDir, "fill.png")
    fun dateFillFile() = File(ctx.filesDir, "date_fill.png")
    fun circleFillFile(i: Int) = File(ctx.filesDir, "circle_fill_$i.png")
    fun logoFile(i: Int) = File(ctx.filesDir, "logo_$i.png")

    fun loadLogo(i: Int): Bitmap? {
        val f = logoFile(i)
        if (!f.exists()) return null
        return try {
            BitmapFactory.decodeFile(f.absolutePath)
        } catch (e: Exception) {
            null
        }
    }
}
