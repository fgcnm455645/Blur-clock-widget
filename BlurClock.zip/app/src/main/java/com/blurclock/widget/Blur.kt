package com.blurclock.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import kotlin.math.roundToInt

object Blur {

    /** Fill for the clock/date: the wallpaper area under the clock widget, blurred and tinted white. */
    fun buildFill(wall: Bitmap, s: ClockSettings, blurAmount: Int, whiteAmount: Int): Bitmap =
        buildRegion(wall, s, s.posX, s.posY, s.widthFrac, s.heightFrac, blurAmount, whiteAmount, 0)

    /**
     * Fill for the clock digits. Plain blur + white, or (color blur on) the blurred wallpaper tinted with
     * the chosen color (mixed into the blurred wallpaper, so the wallpaper still shows through).
     */
    fun buildClockFill(wall: Bitmap, s: ClockSettings): Bitmap {
        val base = if (s.realGlassActive()) {
            buildFill(wall, s, s.realBlur, if (s.colorOn) 0 else s.realTint)
        } else {
            buildFill(wall, s, s.blur, if (s.colorOn) 0 else s.white)
        }
        if (!s.colorOn) return base
        val tc = s.tintColor()
        val tr = (tc shr 16) and 255
        val tg = (tc shr 8) and 255
        val tb = tc and 255
        val w = base.width
        val h = base.height
        val px = IntArray(w * h)
        base.getPixels(px, 0, w, 0, 0, w, h)
        // The color is mixed into the blurred wallpaper, so the wallpaper (e.g. the aurora) still
        // shows through, blurred. Solid = dense color, glass = lighter, more see-through tint.
        val a = if (s.colorSolid) 0.55f + 0.40f * s.colorStrength / 100f
        else 0.15f + 0.60f * s.colorStrength / 100f
        for (i in px.indices) {
            val c = px[i]
            val r = (((c shr 16) and 255) * (1f - a) + tr * a).roundToInt().coerceIn(0, 255)
            val g = (((c shr 8) and 255) * (1f - a) + tg * a).roundToInt().coerceIn(0, 255)
            val b = ((c and 255) * (1f - a) + tb * a).roundToInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
        }
        base.setPixels(px, 0, w, 0, 0, w, h)
        return base
    }

    /** Crops a region of the wallpaper (fractions of the screen), blurs it, then tints it dark and/or white. */
    fun buildRegion(
        wall: Bitmap, s: ClockSettings,
        posX: Float, posY: Float, wFrac: Float, hFrac: Float,
        blurAmount: Int, whiteAmount: Int, darkAmount: Int
    ): Bitmap {
        val w = (wFrac * s.wallW).roundToInt().coerceIn(2, wall.width)
        val h = (hFrac * s.wallH).roundToInt().coerceIn(2, wall.height)
        val x = (posX * s.wallW).roundToInt().coerceIn(0, wall.width - w)
        val y = (posY * s.wallH).roundToInt().coerceIn(0, wall.height - h)
        val crop = Bitmap.createBitmap(wall, x, y, w, h)

        var result: Bitmap = crop
        val radius = (blurAmount * 0.35f).roundToInt()
        if (radius >= 1) {
            val small = Bitmap.createScaledBitmap(crop, maxOf(1, w / 4), maxOf(1, h / 4), true)
            val blurred = blurBitmap(small, radius)
            result = Bitmap.createScaledBitmap(blurred, w, h, true)
        }
        val out = result.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        if (darkAmount > 0) {
            val a = (darkAmount / 100f * 0.9f * 255f).roundToInt()
            canvas.drawColor(Color.argb(a, 0, 0, 0))
        }
        if (whiteAmount > 0) {
            val a = (whiteAmount / 100f * 0.9f * 255f).roundToInt()
            canvas.drawColor(Color.argb(a, 255, 255, 255))
        }
        return out
    }

    fun blurBitmap(src: Bitmap, radius: Int): Bitmap {
        if (radius < 1) return src
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        repeat(3) {
            pass(px, w, h, radius, true)
            pass(px, w, h, radius, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    private fun pass(px: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val step = if (horizontal) 1 else w
        val div = 2 * r + 1
        val tmp = IntArray(len)
        for (line in 0 until lines) {
            val start = if (horizontal) line * w else line
            var sr = 0
            var sg = 0
            var sb = 0
            for (i in -r..r) {
                val c = px[start + i.coerceIn(0, len - 1) * step]
                sr += (c shr 16) and 255
                sg += (c shr 8) and 255
                sb += c and 255
            }
            for (x in 0 until len) {
                tmp[x] = (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = px[start + minOf(x + r + 1, len - 1) * step]
                val sub = px[start + maxOf(x - r, 0) * step]
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
            for (x in 0 until len) px[start + x * step] = tmp[x]
        }
    }
}
